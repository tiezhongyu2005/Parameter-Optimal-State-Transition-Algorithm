function y = Sphere(x)
% Sphere function
% -100 <= x  <= 100
y = sum(x.^2);