function [Best,fBest] = rotate_w(funfcn,Best,fBest,SE,Range,Omega)
[Best,fBest,alpha] = update_alpha(funfcn,Best,fBest,SE,Range,Omega);
for i = 1:10
    [Best,fBest] = rotate(funfcn,Best,fBest,SE,Range,alpha);
end