function [Best,fBest] = expand_w(funfcn,Best,fBest,SE,Range,Omega)
[Best,fBest,gamma] = update_gamma(funfcn,Best,fBest,SE,Range,Omega);
for i = 1:10
    [Best,fBest] = expand(funfcn,Best,fBest,SE,Range,gamma);
end
